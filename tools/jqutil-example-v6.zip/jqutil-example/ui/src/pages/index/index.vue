<template>
  <div class="wrapper">
    <text class="jump-message" @click="testJoinPath">testJoinPath</text>
    <text class="jump-message" @click="testReadFile">testReadFile</text>
    <text class="jump-message" @click="testRequestHttp">testRequestHttp</text>
    <text class="jump-message" @click="testScanWifi">testScanWifi</text>
  </div>
</template>

<script>
import {foo, fooWifi} from 'hello'

export default {
  name: "index",
  data() {
    return {
      message: "",
    };
  },
  methods: {
    sayHello() {
      this.message = "Hello";
    },
    testJoinPath() {
      console.log(`testJoinPath called`)
      const path = foo.joinPath('root', 'works', 'project')
      console.log(`pathJoin result ${path}`)
    },
    async testReadFile() {
      console.log(`testReadFile called`)
      const content = await foo.readFile('/some/path/of/file')
      console.log(`readFile result ${content}`)

    },
    async testRequestHttp() {
      console.log(`testRequestHttp called`)
      const body = await foo.requestHttp('http://host:port/and/url')
      console.log(`requestHttp result ${body}`)
    },
    testScanWifi() {
      console.log(`testScanWifi called`)
      fooWifi.on('scan_result', (res) => {
        console.log(`got scan_result ${JSON.stringify(res)}`)
      })
      fooWifi.scanWifi()
    },
  },
};
</script>

<style lang="less" scoped>
@import "../../styles/base.less";

.wrapper {
  justify-content: center;
  align-items: center;
}
.greeting {
  text-align: center;
  margin-top: 20px;
  font-size: 50px;
  color: #41b883;
}
.jump-message {
  margin: 24px;
  font-size: 32px;
  color: #727272;
}
.message {
  font-size:20px;
  color: #727272;
  margin-top:12px;
}
.btn {
  .shadow();
}

.fl-doc-demo-block {
  &__title {
    margin: 0;
    padding: 32px 16px 16px;
    color: @text-color-default;
    font-size: 14px;
    line-height: 16px;
  }
}
</style>
