#include "jqutil_v2/jqutil.h"
#include "jsmodules/JSCModuleExtension.h"
#include "jquick_config.h"

using namespace JQUTIL_NS;

namespace hello {

extern int foo_init(JQModuleEnv* env);

static std::vector<std::string> exportList = {
    "foo", "fooWifi"
};

static int module_init(JSContext *ctx, JSModuleDef *m) {
    JQuick::sp<JQModuleEnv> env = JQModuleEnv::CreateModule(ctx, m, "hello");

    foo_init(env.get());

    env->setModuleExportDone(JS_UNDEFINED, exportList);
    return 0;
}

DEF_MODULE_LOAD_FUNC_EXPORT(hello, module_init, exportList)

}  // namespace hello

extern "C" JQUICK_EXPORT void custom_init_jsapis()
{
    registerCModuleLoader("hello", &hello::hello_module_load);
}

